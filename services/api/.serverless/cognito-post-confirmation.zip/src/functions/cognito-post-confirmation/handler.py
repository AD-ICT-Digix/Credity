import json
import os
import boto3


def main(event, context):
    # Get the DynamoDB resource
    dynamodb = boto3.resource("dynamodb")
    table = dynamodb.Table(os.environ["TABLE_NAME"])

    print(table)

    print(os.environ)
    print(os.environ["REGION"])
    print(os.environ["TABLE_NAME"])

    # print all values inside Key
    print("Values in Key:")
    print("pk: " + f"USER#{event['userName']}")
    print("sk: " + f"USER#{event['userName']}")
    print("type: " + "USER")
    print("email: " + event["request"]["userAttributes"]["email"])
    print("createdAt: " + event["request"]["userAttributes"]["sub"])
    print("updatedAt: " + event["request"]["userAttributes"]["sub"])

    # Create a new user in the database
    response = table.put_item(
        Item={
            "pk": f"USER#{event['userName']}",
            "sk": f"USER#{event['userName']}",
            "type": "USER",
            "email": event["request"]["userAttributes"]["email"],
        },
    )

    # Return the event for further processing by AWS Cognito
    return event
